# Change Log
##  Search Spell Correction [mirasvit/module-misspell]


## 1.0.34
*(2019-10-08)*

#### Fixed
* Misspell split functionality
* Set misspell tables to MyISAM engine


---


## 1.0.33
*(2019-09-18)*

#### Fixed
* Spell correction don't return suggested result

---


## 1.0.32
*(2019-08-13)*

#### Fixed
* Marketplace compatibility

---


## 1.0.31
*(2019-05-27)*

#### Fixed
* Generators cannot return values using “return” 

---


## 1.0.29
*(2019-02-12)*

#### Fixed
* Allowed memory size error

---


## 1.0.28
*(2018-11-29)*

#### Fixed
* Compatibility with Magento 2.3

---


## 1.0.27
*(2018-10-01)*

#### Fixed
* ECHO

---



## 1.0.26
*(2018-09-19)*

#### Fixed
* Issue with first suggesting in some cases

---


## 1.0.24
*(2018-05-31)*

#### Fixed
* Issue with indexation cyrilic terms

---


## 1.0.23
*(2018-04-11)*

#### Fixed
* Issue with error 22003

---



## 1.0.22
*(2017-12-25)*

#### Improvements
* Integrated with Search Autocomplete
* Added Reindex validator

---

### 1.0.21
*(2017-12-13)*

#### Improvements
* Fallback search logic

---

### 1.0.20
*(2017-11-17)*

#### Fixed
* Issue with _cl table

---

### 1.0.19
*(2017-10-26)*

#### Fixed
* Possible issue with null values during indexation

---

### 1.0.18
*(2017-09-28)*

#### Fixed
* Issue with calculation number of results for suggested search phrase

---

### 1.0.17
*(2017-09-26)*

#### Fixed
* M2.2
* Issue with highlighting

---

### 1.0.16
*(2017-08-09)*

#### Fixed
* Issue with check zero result

---

### 1.0.15
*(2017-07-12)*

#### Fixed
* Issue with Changelog changes

---

### 1.0.14
*(2017-07-10)*

#### Improvements
* Fallback search logic

---

### 1.0.13
*(2017-06-20)*

#### Fixed
* Compatibility issue with Amasty Shopby

---

### 1.0.12
*(2017-05-10)*

#### Improvements
* Remove spell correction index if it disabled

---

### 1.0.11
*(2017-04-11)*

#### Improvements
* Switched to API interfaces

---

### 1.0.10
*(2017-02-20)*

#### Improvements
* Changed all string fuctions to mb_*

---


### 1.0.9
*(2017-02-03)*

#### Improvements
* Added Recurring setup script for check fulltext indices

---

### 1.0.8
*(2016-11-21)*

#### Improvements
* Compatibility with M 2.2.0

---

### 1.0.7
*(2016-06-24)*

#### Fixed
* Compatibility with Magento 2.1

---

### 1.0.6
*(2016-06-16)*

#### Fixed
* Fixed an issue with changing index mode for misspell index

---

### 1.0.5
*(2016-04-27)*

#### Improvements
* Improved extension performance
* i18n

#### Documentation
* Updated installation steps

---

### 1.0.4
*(2016-02-23)*

#### Fixed
* Fixed an issue with segmentation fault during reindex (PHP7)

---

### 1.0.3
*(2016-02-07)*

#### Documentation
* Added user manual


##  Search Autocomplete & Suggest [mirasvit/module-search-autocomplete]


## 1.1.105
*(2019-01-02)*

#### Fixed
* Disable native search autocomplete

---

## 1.1.104
*(2019-12-18)*

#### Fixed
* Blackbird contentmanager index

---

## 1.1.103
*(2019-12-16)*

#### Fixed
* Add blackbird contentmanager index

#### Improvements
* Product search index refactoring

---

## 1.1.102
*(2019-12-09)*

#### Fixed
* Rating issue

---

## 1.1.101
*(2019-12-03)*

#### Fixed
* Wrong search results breadcrumbs
* Rating issue

---


## 1.1.100
*(2019-11-25)*

#### Improvements
* Use default magento price block for search autocomplete

---


## 1.1.99
*(2019-11-25)*

#### Fixed
* Unable to apply 'Add to Cart' translation
* Missing product rating
* Category index results wrong urls in fast mode
* CMS page index results wrong urls in fast mode

---


## 1.1.98
*(2019-11-14)*

#### Fixed
* Conflict with Webkul ShowPriceAfterlogin

---


## 1.1.97
*(2019-11-12)*

#### Fixed
* Search Button is not clickable when selecting the term from the Hot Searches

---


## 1.1.96
*(2019-08-08)*

#### Fixed
* Issue with wrong layer

---


## 1.1.95
*(2019-08-06)*

#### Fixed
* Prices issue for multistore setup in 'Fast Mode'
* Product thumbnails issue in 'Fast Mode'

---


## 1.1.94
*(2019-07-31)*

#### Fixed
* Issue with autocomplete visibility, even if cart popoup was showed

---


## 1.1.93
*(2019-07-30)*

#### Features
* Fishpig Glossary index support

#### Fixed
* native search form active state
* nested environment emulation error
* reindex speedup
* Blinking autocomplete box with multiple search forms on the same page

---


## 1.1.92
*(2019-06-19)*

#### Fixed
* Render html entities on server side
* KB article typo in template
* Remove .active when on autocomplete miss focus


## 1.1.91
*(2019-04-26)*

#### Fixed
* conflict with IE 10

#### Improvements
* Added message after fast mode enable


## 1.1.90
*(2019-04-24)*

#### Fixed
* Ensure search autocomplete Fast Mode config file on reindex
* Display Fast mode indexes in correct order
---


## 1.1.89
*(2019-04-12)*

#### Fixed
* incorrect module conflict declaration
---


## 1.1.88
*(2019-04-08)*

#### Fixed
* Similar results in multiple attribute indexes

---


## 1.1.87
*(2019-04-01)*

#### Fixed
* Translations for search in stores with fast mode

#### Improvements
* Improved weighting, ability to use advansed search options, synonyms, stopwords
---


## 1.1.86
*(2019-03-13)*

#### Fixed
* Search in stores with fast mode

---




##  Search Landing Page [mirasvit/module-search-landing]


## 1.0.8
*(2019-09-09)*

#### Fixed
* EQP

---


## 1.0.7
*(2019-06-04)*

#### Fixed
* Issue with different url keys for landing pages on different stores

---


## 1.0.6
*(2018-11-29)*

#### Fixed
* Compatibility with Magento 2.3

---


## 1.0.5
*(2018-10-10)*

#### Improvements
* Multistore

---


## 1.0.4
*(2018-04-12)*

#### Features
* Allow redirect by search term to url key 

---

### 1.0.3
*(2017-09-26)*

#### Fixed
* M2.2

---

### 1.0.2
*(2017-07-25)*

#### Fixed
* Issue with static tests

---

### 1.0.1
*(2017-05-03)*

#### Fixed
* Issue with UI

---

### 1.0.0
*(2017-05-03)*

* Initial release

------

##  Search Report [mirasvit/module-search-report]


## 1.0.6
*(2019-11-14)*

#### Fixed
* Conflict with Paysera payment methods

---

## 1.0.5
*(2018-08-21)*

#### Fixed
* Report settings do not work

---

## 1.0.4
*(2018-04-20)*

#### Fixed
* Issue with report by search terms

---

## 1.0.3
*(2018-02-14)*

#### Improvements
* Switched to new module-report version

#### Fixed
* Added details for secure cookies
added details for secure cookies

---

### 1.0.2
*(2017-09-26)*

#### Fixed
* M2.2

---

### 1.0.1
*(2017-07-21)*

#### Fixed
* Possible issue with "Circular dependency"

---


##  Search Sphinx [mirasvit/module-search-sphinx]


## 1.1.51
*(2020-01-02)*

#### Improvements
* Inform customer if sphinx port already used by another instance

---

## 1.1.50
*(2019-11-13)*

#### Improvements
* Display solution along with error text

---

## 1.1.49
*(2019-08-13)*

#### Fixed
* Marketplace compatibility

---

## 1.1.48
*(2019-08-02)*

#### Fixed
* Advanced search issue
* Keep Sphinx folder on 'Reset' from admin

---

## 1.1.47
*(2019-06-27)*

#### Fixed
* Magento 2.3.2 compatibility

---

## 1.1.46
*(2019-05-21)*

#### Fixed
* sphinx reindex issue

---

## 1.1.45
*(2019-04-18)*

#### Fixed
* Skip non-searchable attributes while search reindex

---

## 1.1.44
*(2019-04-01)*

#### Improvements
* Ability to use advansed search options, synonyms, stopwords in fast mode

---
## 1.1.43
*(2018-11-29)*

#### Fixed
* Search in stores with fast mode

---

## 1.1.42
*(2018-11-29)*

#### Fixed
* Compatibility with Magento 2.3

---

## 1.1.41
*(2018-11-01)*

#### Fixed
* missing BP constant issue

---

## 1.1.40
*(2018-10-24)*

#### Fixed
* Issue with cleanIndex for Sphinx engine

---

## 1.1.39
*(2018-10-16)*

#### Fixed
* Instance for '' not found
* unexpected BAD_NUMERIC 

---

## 1.1.38
*(2018-09-20)*

#### Fixed
* Reindex issue

---

## 1.1.37
*(2018-09-20)*

#### Fixed
* Reindex issue

---

## 1.1.36
*(2018-09-19)*

#### Fixed
* Issue with ves blog

---

## 1.1.35
*(2018-09-12)*

#### Improvements
* Multi-indexes for one type

---

## 1.1.34
*(2018-09-11)*

#### Improvements
* Compatibility

#### Fixed
* Issue with fast autocomplete

---

## 1.1.33
*(2018-07-31)*

#### Improvements
* Full reindex time

---

## 1.1.32
*(2018-07-11)*

#### Fixed
* Sphinx does not search by keywords with dash

---

## 1.1.31
*(2018-07-05)*

#### Improvements
* Wirdcard match more relevant then exact match

---

## 1.1.30
*(2018-07-02)*

#### Improvements
* Autostart on search

---

## 1.1.29
*(2018-06-18)*

#### Fixed
* Issue with di:compile

---

## 1.1.28
*(2018-06-18)*

#### Fixed
* Autocomplete config

---

## 1.1.27
*(2018-06-14)*

#### Fixed
* Wrong echo

---

## 1.1.26
*(2018-06-14)*

#### Features
* Fast mode for Search Autocomplete

---

## 1.1.25
*(2018-04-20)*

#### Fixed
* Sphinx special chars

---

## 1.1.24
*(2018-02-16)*

#### Features
* add gift registry search index for sphinx


---

## 1.1.23
*(2017-12-18)*

#### Fixed
* Issue with synonyms

---

### 1.1.22
*(2017-12-14)*

#### Fixed
* Removed symfony/yaml requirement

---

### 1.1.21
*(2017-11-24)*

#### Fixed
* MySQL server has gone away
* PHP 7.2 compatibility

---

### 1.1.20
*(2017-10-24)*

#### Fixed
* Issue with filtration

---

### 1.1.19
*(2017-10-17)*

#### Fixed
* Issue with relative path

---

### 1.1.18
*(2017-10-11)*

#### Improvements
* Ability to define custom sphinx path

---

### 1.1.17
*(2017-10-06)*

#### Improvements
* Ability to define custom charset_table

---

### 1.1.16
*(2017-09-26)*

#### Fixed
* M2.2

---

### 1.1.15
*(2017-09-21)*

#### Fixed
* Issue with escape

---

### 1.1.14
*(2017-09-15)*

#### Fixed
* Issue with fresh installation

---

### 1.1.13
*(2017-08-11)*

#### Fixed
* Issue with category pages

---

### 1.1.12
*(2017-08-10)*

#### Fixed
* Support 'not-words' with sphinx search engine

---

### 1.1.11
*(2017-07-28)*

#### Fixed
* Issue with category pages

---

### 1.1.10
*(2017-07-21)*

#### Improvements
* Option to enable/disable sphinx daemon auto start

---

### 1.1.9
*(2017-06-29)*

#### Fixed
* Kb provider

---

### 1.1.8
*(2017-06-26)*

#### Fixed
* Issue with weight

---

### 1.1.7
*(2017-06-20)*

#### Fixed
* Issue with relevance

---

### 1.1.6
*(2017-05-19)*

#### Fixed
* Issue with infix len
* Issue with one char search

---

### 1.1.4
*(2017-05-05)*

#### Improvements
* Sphinx manage CLI

---

### 1.1.3
*(2017-04-14)*

#### Fixed
* Suggestions data provider

---

### 1.1.2
*(2017-04-13)*

#### Fixed
* Issues with indexation

---

### 1.1.1
*(2017-04-04)*

#### Fixed
* Fixed an issue with requirements

---

### 1.1.0
*(2017-04-04)*

#### Improvements
* Split modules

---

### 1.0.60
*(2017-02-06)*

#### Fixed
* Fixed an issue with default sort direction

---

### 1.0.59
*(2017-02-06)*

#### Fixed
* Fixed a set of issue related with data serialization
* Issue with feature "push out of stock products"

---

### 1.0.57
*(2017-01-24)*

#### Fixed
* Fixed singularize issue in Dutch language (affects all)
* Fixed an issue with catalog attribute index

---

### 1.0.56
*(2017-01-20)*

#### Improvements
* Increased number of sphinx client max_children

---

### 1.0.55
*(2017-01-20)*

#### Improvements
* Added new search index: Catalog Attributes

---

### 1.0.54
*(2017-01-13)*

#### Fixed
* Fixed an issue with store based configuration

---

### 1.0.53
*(2017-01-12)*

#### Improvements
* Added search index for Ves Brands
* Added search index for Ves Blog
* Backend interface

---

### 1.0.52
*(2016-12-23)*

#### Fixed
* Fixed an issue with out of stock products

---

### 1.0.51
*(2016-12-21)*

#### Fixed
* Fixed an issue with new block

#### Documentation
* updated docs

---

### 1.0.50
*(2016-12-16)*

#### Features
* Smart "No Results" page

---

### 1.0.49
*(2016-12-01)*

#### Improvements
* Improved stemming feature (stemming based on current store locale)
### 1.0.48
*(2016-11-30)*

#### Improvements
* Custom search weight for products

---

### 1.0.47
*(2016-11-23)*

#### Fixed
* Fixed an issue with terms highlighter

---

### 1.0.46
*(2016-11-21)*

#### Improvements
* Fixed possible issue with swatches

---

### 1.0.45
*(2016-11-21)*

#### Improvements
* Compatibility with M 2.2.0

---

### 1.0.44
*(2016-11-17)*

#### Fixed
* Fixed an issue with search terms highlighting (char &)
* Issue with compare option on search results page

---

### 1.0.43
*(2016-10-31)*

#### Fixed
* Fixed an issue with one char wildcard
* Fixed an issue with terms highlighter
* Fixed an issue with number in attribute code
#### Features
* Added ability to generate sphinx configuration file for another sphinx server

---

### 1.0.40
*(2016-10-12)*

#### Fixed
* Fixed an issue with memory limits during indexation
* Fixed an issue with built-in search by very large description

---

### 1.0.38
*(2016-10-10)*

#### Fixed
* Fixed an issue with indexes translations

---

### 1.0.37
*(2016-10-04)*

---

### 1.0.36
*(2016-09-27)*

#### Improvements
* Ability to set custom search weight for products

---

### 1.0.34
*(2016-09-07)*

#### Improvements
* Prepare cms block during categories reindex

#### Fixed
* Fixed an issue with multistore results + added redirect via native store switcher controller

---

### 1.0.32
*(2016-08-19)*

#### Improvements
* Ability to search by blocks content in cms pages

#### Fixed
* Fixed an sphinx issue related with attributes

---

### 1.0.31
*(2016-08-09)*

#### Fixed
* Fixed an issue with sphinx index attributes

---
### 1.0.30
*(2016-08-06)*

#### Fixed
* Fixed an issue with category index (multi-store configuration)

---

### 1.0.28
*(2016-07-07)*

#### Improvements
* Added pager to wordpress blog search results

#### Fixed
* Fixed an issue related with creating temporary table on external database (external wordpress blog)

---

### 1.0.27
*(2016-07-06)*

#### Fixed
* Fixed an issue with displaying inline blocks, when search by cms pages
* Search sphinx with 2.1
* Fixed an issue with multi-store configuration

---
### 1.0.26
*(2016-06-29)*

#### Fixed
* Fixed an issue with applying results limit on category page

---

### 1.0.25
*(2016-06-29)*

#### Improvements
* Added additional exceptions for 404 to redirect

---

### 1.0.24
*(2016-06-24)*

#### Fixed
* Compatibility with Magento 2.1
* Fixed an issue with "Enable redirect from 404 to search results"

---
### 1.0.23
*(2016-06-14)*

#### Features
* Ability to reset sphinx daemon

---

### 1.0.22
*(2016-06-08)*

#### Fixed
* Fixed an issue with multistore results

---

### 1.0.21
*(2016-06-07)*

#### Improvements
* Added ability to search by Magefan Blog module

---

### 1.0.20
*(2016-05-24)*

#### Improvements
* Added special chars to sphinx configuration charset table

---

### 1.0.19
*(2016-05-19)*

#### Improvements
* Moved SphinxQL lib to module

#### Fixed
* Fixed an issue with synonyms

---

### 1.0.18
*(2016-05-17)*

#### Improvements
* Added additional file extension exceptions to 404 observer

#### Fixed
* Fixed an issue with min_word_len (search with dashes 0-1)

---

### 1.0.17
*(2016-05-16)*

#### Fixed
* SSU2-13 - Fix issue with synonyms

---

### 1.0.15, 1.0.16
*(2016-05-12)*

#### Improvements
* Improved performance of query builder

#### Fixed
* Fixed an sphinx query error after adding new attribute

---

### 1.0.14
*(2016-04-26)*

#### Fixed
* Fixed an issue with cronjobs

---

### 1.0.13
*(2016-04-20)*

#### Improvements
* Added console command for reindex search indexes

#### Fixed
* Fixed an issue with search by child product SKU
* Fixed css issue with active search tab, when HTML minification is enabled
* Fixed an issue with menu
* Fixed an issue with score builder for mysql engine

---

### 1.0.12
*(2016-04-07)*

#### Fixed
* Fixed an issue with area code (cli mode)
* Fixed an javascript error when html minification is enabled
* Fixed an issue with plural queries

---

### 1.0.11
*(2016-03-25)*

#### Improvements
* Integrated Mirasvit Knowledge Base

---

### 1.0.10
*(2016-03-17)*

#### Improvements
* Default index configuration
* Ability to search products only in active categories

#### Fixed
* Fixed possible issue with score sql query
* Fixed an issue with results limit

#### Documentation
* Description for Search only by active categories
* Updated installation steps

---

### 1.0.9
*(2016-03-09)*

#### Improvements
* Default index configuration
* Improved feature 404 to search
* Console commands for import/remove synonyms/stopwords
* Added default lemmatizer for EN, DE
* Improved sphinx configuration file
* Fallback engine for sphinx
* SSU2-9 -- Search by Mirasvit Blog MX
* i18n

#### Documentation
* Updated installation steps
* Information about synonyms and stopwords

#### Fixed
* Fixed an issue with stopwords import controller
* Added Symfony/Yaml to required packages
* Fixed an issue with importing synonyms and stopwords
* Fixed an issue with product list toolbar
* Fixed compatibility issue with Manadev_LayeredNavigation
* SSU2-8 -- mysql2 not found, when save product

---

### 1.0.8
*(2016-02-24)*

#### Fixed
* Fixed an issue with segmentation fault (PHP7) during reindex

---

### 1.0.7
*(2016-02-15)*

#### Fixed
* Fixed an issue with special chars in sphinx query (@)
* Fixed an issue with "Default Category" in search results for category search index
* Updated MCore version
* Formatting
* Fixed an issue with number of products at category pages (limit, offset)

---

### 1.0.6
*(2016-02-02)*

#### Fixed
* Fixed an issue with NOT cacheable block "search.google.sitelinks"
* Fixed an issue with upgrade script (synonyms and stopwords)
* SSU2-3 -- Fixed an issue with sh output in console (sh: searchd: command not found)

---

### 1.0.5
*(2016-01-31)*

#### Features
* SSU2-1 - Multi-store search results

#### Fixed
* Itegration tests

---

