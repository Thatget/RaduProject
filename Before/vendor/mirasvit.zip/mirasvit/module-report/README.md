cd ui
npm run install