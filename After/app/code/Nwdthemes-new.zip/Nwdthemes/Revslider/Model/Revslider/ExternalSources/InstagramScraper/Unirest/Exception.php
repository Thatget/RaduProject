<?php

namespace Nwdthemes\Revslider\Model\Revslider\ExternalSources\InstagramScraper\Unirest;

class Exception extends \Exception {}
