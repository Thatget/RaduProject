var config = {
    "map": {
        '*': {
            'nwdthemes/jquery.easing' : 'Nwdthemes_Base/js/jquery.easing',
            'nwdthemes/owl.carousel' : 'Nwdthemes_Base/js/owl.carousel',
            'nwdthemes/owl.carousel.min' : 'Nwdthemes_Base/js/owl.carousel.min'
        }
    },
    "shim": {
        "nwdthemes/owl.carousel": ["jquery"],
        "nwdthemes/owl.carousel.min": ["jquery"]
    }
};