require(['codemirror', 'cmMatchHighlighter', 'cmSearchCursor', 'cmCss', 'cmXml'], function(CodeMirror) {
});