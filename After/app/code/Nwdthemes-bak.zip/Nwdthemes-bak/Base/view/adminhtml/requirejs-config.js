var config = {
    paths: {
        jscolor: 'Nwdthemes_Base/js/jscolor.min'
    },
    shim: {
        jscolor: {
            exports: 'jscolor'
        }
    }
};